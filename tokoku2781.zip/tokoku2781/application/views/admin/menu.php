<div class="container mt-4">
    <div class="row">
        <div class="col-md-3">
            <!-- Sidebar -->
            <ul class="list-group">
                <li class="list-group-item active">Dashboard</li>
                <li class="list-group-item"><a href="<?= site_url('kategori'); ?>">Manage Kategori</a></li>
                <li class="list-group-item"><a href="<?= site_url('merek'); ?>">Manage Merek</a></li>
                <li class="list-group-item"><a href="<?= site_url('promo'); ?>">Manage Promo</a></li>
                <li class="list-group-item"><a href="<?= site_url('pembeli'); ?>">Manage Pembeli</a></li>
                <li class="list-group-item"><a href="<?= site_url('admin1'); ?>">Manage Admin</a></li>
                <li class="list-group-item"><a href="<?= site_url('admin1/pesanan'); ?>">Manage Pesanan</a></li>
            </ul>
        </div>
        <div class="col-md-9">
