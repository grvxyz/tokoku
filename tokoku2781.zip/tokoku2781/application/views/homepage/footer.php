
</div> <!-- Tutup .wrapper dari header -->

    <!-- Footer -->
    <footer style="background-color: #00a96e; width: 100%; color: #fff; text-align: center; padding: 15px 0; margin-top: auto;">
        <p class="mb-0">&copy; 2025 Marketplace. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
